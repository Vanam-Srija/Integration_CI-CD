import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    def body = message.getBody(String)
    def xml = new XmlParser().parseText(body)

    // Wrap repeated children under <item> inside the given node
    def wrapNodeItems = { parent, nodeName ->
        def target = parent[nodeName]
        if (target && target.size() > 0) {
            target.each { node ->
                def children = node.children().findAll { it instanceof Node }
                if (children && children.size() > 0 && !(children[0].name() == 'item')) {
                    // Remove original children
                    node.value = []

                    // Wrap each record in <item>
                    children.each { child ->
                        def itemNode = new Node(node, 'item')
                        child.clone().each {
                            itemNode.append(it)
                        }
                    }
                }
            }
        }
    }

    wrapNodeItems(xml, 'to_Item')
    wrapNodeItems(xml, 'to_Partner')
    wrapNodeItems(xml, 'to_PricingElement')

    def writer = new StringWriter()
    new XmlNodePrinter(new PrintWriter(writer)).print(xml)
    message.setBody(writer.toString())
    return message
}
