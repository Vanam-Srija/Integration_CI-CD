import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    def found = false
    if (json?.d?.results && json.d.results.size() > 0) {
        // SalesOrder exists
        found = true
        message.setProperty("ExistingSalesOrder", json.d.results[0].SalesOrder)
    }

    message.setProperty("SalesOrderFound", found)
    return message
}
